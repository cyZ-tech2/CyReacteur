#include "../include/maths.h"

// Fonction max
int max(int a, int b) {
    return a > b ? a : b;
}

// Fonction min
int min(int a, int b) {
    return a < b ? a : b;
}
